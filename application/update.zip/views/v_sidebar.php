

        <aside class="main-sidebar sidebar-dark-primary elevation-4">

            <a href="index3.html" class="brand-link">
                <span class="brand-text font-weight-light">ManageAPI</span>
            </a>

            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">

                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-circle"></i>
                                <p>
                                    Main Menu
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo base_url().'admin'?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>API History List</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url().'recordsubmissionlist'?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Records Submitted</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url().'apikeylist'?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>API Key List</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url().'apilist'?>" class="nav-link">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>API List</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>

            </div>

        </aside>
